var canvas = document.getElementsByTagName('canvas')[0];

console.log(canvas)

canvas.height = window.innerHeight;
canvas.width = window.innerWidth;

var context = canvas.getContext("2d");

//Fill / Stroke


//draw text

context.strokeStyle = "black"
context.fillStyle = "aqua"
context.font = "50px Algerian";
context.fillText("Hello", 50, 50)
context.strokeText("Hello", 50, 50)

//draw rect
context.fillRect(50, 50, 100, 100)
context.strokeRect(100, 100, 100, 100)

//draw image

class Circle
{
	constructor(x, y, radius, color, velocityY)
	{
		this.x = x;
		this.y = y;
		this.radius = radius;
		this.color = color;
		this.velocityY = velocityY;
	}
}

var snows = []
var bgImg = document.getElementsByTagName('img')[0];

var ballPlay = new Circle(canvas.width/2, canvas.height/2, 50, "gold", 0)

window.onload = function()
{
	bgImg.src = 'bg.jpg'
	// context.drawImage(bgImg, 0, 0, canvas.width, canvas.height)

	//draw arc
	// context.fillStyle = "black"
	// context.beginPath()
	// context.arc(canvas.width/2, canvas.height/2, 150, 0, 360)
	// context.fill()

	//draw path
	// context.strokeStyle = "red"
	// context.lineWidth = 10;
	// context.beginPath()
	// context.moveTo(50,50)
	// context.lineTo(150,150)
	// context.moveTo(50, 150)
	// context.closePath()
	// context.stroke()

	//generate salju ke array
	for(var i =0; i < 100;i++)
	{
		var radius = 15
		snows.push(new Circle(
			Math.floor(Math.random()*(canvas.width- 2*radius))+ radius,
			Math.floor(Math.random()*(canvas.height- 2*radius))+ radius,
			radius,
			"white",
			Math.floor(Math.random()*5)
			))
	}

	document.addEventListener('click',resetPosition);
	document.addEventListener('keydown',move);

	requestAnimationFrame(dropSnow)
}

function dropSnow()
{
	//gambar background
	context.drawImage(bgImg, 0, 0, canvas.width, canvas.height)

	//gambar setiap salju
	for(snow of snows)
	{
		context.beginPath();
		context.fillStyle = snow.color;
		context.arc(snow.x, snow.y, snow.radius, 0, 360)
		context.fill();
		
		//turunin salju
		snow.y += snow.velocityY;
		//kalau salju sudah dibawah, di reset jadi atas lagi posisi nya
		if(snow.y + snow.radius >= canvas.height)snow.y = - snow.radius;
	}
	

	//bikin ballPlay nya
	context.beginPath()
	context.fillStyle = ballPlay.color;
	context.arc(ballPlay.x, ballPlay.y, ballPlay.radius, 0, 360)
	context.fill();
	requestAnimationFrame(dropSnow)
}

//fungsi kalau di klik
function resetPosition(e)
{
	console.log(e.clientX + " " + e.clientY)
	if(e.clientX >= ballPlay.x-ballPlay.radius &&
		e.clientX <= ballPlay.x+ballPlay.radius &&
		e.clientY >= ballPlay.y-ballPlay.radius &&
		e.clientY <= ballPlay.y+ballPlay.radius)
	{
		ballPlay.x = canvas.width/2;
		ballPlay.y = canvas.height/2;
	}
	
}

//fungsi kalau di press
function move(e)
{
	console.log(e.keyCode)
	if(e.keyCode == 38)ballPlay.y -=10;
	if(e.keyCode == 40)ballPlay.y +=10;
	if(e.keyCode == 37)ballPlay.x -=10;
	if(e.keyCode == 39)ballPlay.x +=10;
	console.log("Y Coord: " + ballPlay.y)
}



